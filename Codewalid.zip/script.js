const learningContent = `
  <h2>محاور التعلم</h2>
  <ul>
    <li>أساسيات السياقة: قواعد السلامة، إشارات المرور.</li>
    <li>كيفاش تركز فالطريق.</li>
    <li>المناورات والتوقف الصحيح.</li>
    <li>معلومات تقنية على السيارة.</li>
  </ul>
`;

const quizQuestions = [
  {
    question: "شنو كتعني إشارة الوقوف؟",
    options: ["توقف نهائي", "توقف مؤقت", "سرعة بطيئة", "ممنوع المرور"],
    answer: 0,
  },
  {
    question: "كيفاش خاصك تتعامل مع إشارة ضوء أحمر؟",
    options: ["توقف", "تزيد بسرعة", "تسوفى", "توقف إلا إذا كانت الطريق فارغة"],
    answer: 0,
  },
  {
    question: "شنو هي السرعة القانونية فالمدينة؟",
    options: ["50 كم/س", "70 كم/س", "90 كم/س", "30 كم/س"],
    answer: 0,
  },
];

const contentEl = document.getElementById("content");
const btnLearning = document.getElementById("btn-learning");
const btnQuiz = document.getElementById("btn-quiz");

btnLearning.addEventListener("click", () => {
  contentEl.innerHTML = learningContent;
});

btnQuiz.addEventListener("click", () => {
  startQuiz();
});

function startQuiz() {
  let current = 0;
  let score = 0;
  contentEl.innerHTML = "";
  showQuestion(current);

  function showQuestion(index) {
    const q = quizQuestions[index];
    contentEl.innerHTML = `
      <h2>السؤال ${index + 1} من ${quizQuestions.length}</h2>
      <p>${q.question}</p>
      <div id="options"></div>
    `;

    const optionsDiv = document.getElementById("options");
    q.options.forEach((opt, i) => {
      const btn = document.createElement("button");
      btn.textContent = opt;
      btn.onclick = () => {
        if (i === q.answer) score++;
        current++;
        if (current < quizQuestions.length) {
          showQuestion(current);
        } else {
          showResult();
        }
      };
      optionsDiv.appendChild(btn);
    });
  }

  function showResult() {
    contentEl.innerHTML = `
      <h2>النتيجة</h2>
      <p>جبت ${score} من ${quizQuestions.length} صحيحة.</p>
      <button id="retry">جرب مرة أخرى</button>
    `;
    document.getElementById("retry").onclick = startQuiz;
  }
}
